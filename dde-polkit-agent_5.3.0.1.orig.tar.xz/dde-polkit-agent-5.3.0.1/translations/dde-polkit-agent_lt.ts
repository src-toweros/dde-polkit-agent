<?xml version="1.0" ?><!DOCTYPE TS><TS language="lt" version="2.1">
<context>
    <name>AuthDialog</name>
    <message>
        <location filename="../AuthDialog.cpp" line="131"/>
        <source>Verify your fingerprint or password</source>
        <translation>Patvirtinkite savo piršto atspaudą ar slaptažodį</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="269"/>
        <source>Wrong password</source>
        <translation>Neteisingas slaptažodis</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="278"/>
        <source>Cancel</source>
        <translation>Atsisakyti</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="148"/>
        <location filename="../AuthDialog.cpp" line="279"/>
        <source>Confirm</source>
        <translation>Patvirtinti</translation>
    </message>
</context>
</TS>