<?xml version="1.0" ?><!DOCTYPE TS><TS language="el" version="2.1">
<context>
    <name>AuthDialog</name>
    <message>
        <location filename="../AuthDialog.cpp" line="131"/>
        <source>Verify your fingerprint or password</source>
        <translation>Επαλήθευση του δακτυλικού σας αποτυπώματος ή κωδικού πρόσβασης</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="269"/>
        <source>Wrong password</source>
        <translation>Λανθασμένος κωδικός πρόσβασης</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="278"/>
        <source>Cancel</source>
        <translation>Ακύρωση</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="148"/>
        <location filename="../AuthDialog.cpp" line="279"/>
        <source>Confirm</source>
        <translation>Επιβεβαίωση</translation>
    </message>
</context>
</TS>