<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt_BR" version="2.1">
<context>
    <name>AuthDialog</name>
    <message>
        <location filename="../AuthDialog.cpp" line="95"/>
        <source>Finger moved too fast, please do not lift until prompted</source>
        <translation>O dedo se moveu muito rápido; não levante até que seja solicitado</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="97"/>
        <source>Verification failed, two chances left</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="116"/>
        <location filename="../AuthDialog.cpp" line="301"/>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="211"/>
        <source>You are required to change your password immediately (password expired)</source>
        <translation>É necessário alterar a senha imediatamente (a senha expirou)</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="276"/>
        <source>Wrong password, only one chance left</source>
        <translation>Senha incorreta, resta apenas uma tentativa</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="279"/>
        <source>Wrong password, two chances left</source>
        <translation>Senha incorreta; restam duas tentativas</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="283"/>
        <source>Wrong password</source>
        <translation>Senha incorreta</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="300"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
</TS>