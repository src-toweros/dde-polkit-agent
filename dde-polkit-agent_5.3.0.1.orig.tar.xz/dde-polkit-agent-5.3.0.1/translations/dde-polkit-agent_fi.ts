<?xml version="1.0" ?><!DOCTYPE TS><TS language="fi" version="2.1">
<context>
    <name>AuthDialog</name>
    <message>
        <location filename="../AuthDialog.cpp" line="95"/>
        <source>Finger moved too fast, please do not lift until prompted</source>
        <translation>Olet liian nopea, älä nosta sormea ennen kuin pyydetään</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="97"/>
        <source>Verification failed, two chances left</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="116"/>
        <location filename="../AuthDialog.cpp" line="301"/>
        <source>Confirm</source>
        <translation>Vahvista</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="211"/>
        <source>You are required to change your password immediately (password expired)</source>
        <translation>Sinun on vaihdettava salasanasi heti (salasana on vanhentunut)</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="276"/>
        <source>Wrong password, only one chance left</source>
        <translation>Väärä salasana, vain yksi mahdollisuus jäljellä</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="279"/>
        <source>Wrong password, two chances left</source>
        <translation>Väärä salasana, kaksi mahdollisuutta jäljellä</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="283"/>
        <source>Wrong password</source>
        <translation>Väärä salasana</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="300"/>
        <source>Cancel</source>
        <translation>Peruuta</translation>
    </message>
</context>
</TS>