<?xml version="1.0" ?><!DOCTYPE TS><TS language="ug" version="2.1">
<context>
    <name>AuthDialog</name>
    <message>
        <location filename="../AuthDialog.cpp" line="131"/>
        <source>Verify your fingerprint or password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="269"/>
        <source>Wrong password</source>
        <translation>خاتا پارول</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="278"/>
        <source>Cancel</source>
        <translation>بىكار قىلىش</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="148"/>
        <location filename="../AuthDialog.cpp" line="279"/>
        <source>Confirm</source>
        <translation>جەزىملەشتۈرۈش</translation>
    </message>
</context>
</TS>