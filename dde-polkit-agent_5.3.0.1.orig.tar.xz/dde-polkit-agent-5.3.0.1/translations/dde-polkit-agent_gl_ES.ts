<?xml version="1.0" ?><!DOCTYPE TS><TS language="gl_ES" version="2.1">
<context>
    <name>AuthDialog</name>
    <message>
        <location filename="../AuthDialog.cpp" line="131"/>
        <source>Verify your fingerprint or password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="269"/>
        <source>Wrong password</source>
        <translation>Contrasinal non válido</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="278"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="148"/>
        <location filename="../AuthDialog.cpp" line="279"/>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
</context>
</TS>