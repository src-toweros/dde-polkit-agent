<?xml version="1.0" ?><!DOCTYPE TS><TS language="pt" version="2.1">
<context>
    <name>AuthDialog</name>
    <message>
        <location filename="../AuthDialog.cpp" line="95"/>
        <source>Finger moved too fast, please do not lift until prompted</source>
        <translation>Dedo movido muito rápido, por favor, não levante até que seja pedido</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="97"/>
        <source>Verification failed, two chances left</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="116"/>
        <location filename="../AuthDialog.cpp" line="301"/>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="211"/>
        <source>You are required to change your password immediately (password expired)</source>
        <translation>É necessário alterar a palavra-passe imediatamente (palavra-passe expirada)</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="276"/>
        <source>Wrong password, only one chance left</source>
        <translation>Palavra-passe incorreta, resta apenas uma tentativa</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="279"/>
        <source>Wrong password, two chances left</source>
        <translation>Palavra-passe incorreta, restam duas tentativas</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="283"/>
        <source>Wrong password</source>
        <translation>Palavra-passe incorreta</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="300"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
</TS>