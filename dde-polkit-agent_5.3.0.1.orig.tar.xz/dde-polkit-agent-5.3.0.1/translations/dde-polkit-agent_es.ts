<?xml version="1.0" ?><!DOCTYPE TS><TS language="es" version="2.1">
<context>
    <name>AuthDialog</name>
    <message>
        <location filename="../AuthDialog.cpp" line="95"/>
        <source>Finger moved too fast, please do not lift until prompted</source>
        <translation>El dedo se movió demasiado rápido. Por favor, no lo levante hasta que se le indique</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="97"/>
        <source>Verification failed, two chances left</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="116"/>
        <location filename="../AuthDialog.cpp" line="301"/>
        <source>Confirm</source>
        <translation>Confirmar</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="211"/>
        <source>You are required to change your password immediately (password expired)</source>
        <translation>Debe cambiar su contraseña inmediatamente (contraseña expirada)</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="276"/>
        <source>Wrong password, only one chance left</source>
        <translation>Contraseña incorrecta, tiene dos oportunidades restantes</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="279"/>
        <source>Wrong password, two chances left</source>
        <translation>Contraseña incorrecta, tiene dos oportunidades restantes</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="283"/>
        <source>Wrong password</source>
        <translation>Contraseña incorrecta </translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="300"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
</context>
</TS>