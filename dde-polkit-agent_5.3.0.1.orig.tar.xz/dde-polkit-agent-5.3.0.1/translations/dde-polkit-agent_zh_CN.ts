<?xml version="1.0" ?><!DOCTYPE TS><TS language="zh_CN" version="2.1">
<context>
    <name>AuthDialog</name>
    <message>
        <location filename="../AuthDialog.cpp" line="95"/>
        <source>Finger moved too fast, please do not lift until prompted</source>
        <translation>接触时间短，验证时请勿移动手指</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="97"/>
        <source>Verification failed, two chances left</source>
        <translation>验证失败，您还可以尝试2次</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="116"/>
        <location filename="../AuthDialog.cpp" line="301"/>
        <source>Confirm</source>
        <translation>确定</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="211"/>
        <source>You are required to change your password immediately (password expired)</source>
        <translation>您的密码已过期，请更改</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="276"/>
        <source>Wrong password, only one chance left</source>
        <translation>密码错误，只剩1次机会</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="279"/>
        <source>Wrong password, two chances left</source>
        <translation>密码错误，还有2次机会</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="283"/>
        <source>Wrong password</source>
        <translation>密码错误</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="300"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
</TS>