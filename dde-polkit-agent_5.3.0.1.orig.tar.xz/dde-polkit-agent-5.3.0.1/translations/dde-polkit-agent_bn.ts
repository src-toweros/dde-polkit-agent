<?xml version="1.0" ?><!DOCTYPE TS><TS language="bn" version="2.1">
<context>
    <name>AuthDialog</name>
    <message>
        <location filename="../AuthDialog.cpp" line="131"/>
        <source>Verify your fingerprint or password</source>
        <translation>একটি আঙ্গুলের ছাপ অথবা পাসওয়ার্ড যাচাই করুন</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="269"/>
        <source>Wrong password</source>
        <translation>ভুল পাসওয়ার্ড</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="278"/>
        <source>Cancel</source>
        <translation>বাতিল</translation>
    </message>
    <message>
        <location filename="../AuthDialog.cpp" line="148"/>
        <location filename="../AuthDialog.cpp" line="279"/>
        <source>Confirm</source>
        <translation>নিশ্চিত করুন</translation>
    </message>
</context>
</TS>