<a name="0.2.10"></a>
### 0.2.10 (2019-06-04)


#### Bug Fixes

*   auth faild cannot set focus again ([4301d672](https://github.com/linuxdeepin/dde-polkit-agent/commit/4301d672388590a717a0556483073fc552df2967))



<a name="0.2.9"></a>
### 0.2.9 (2019-06-01)


#### Bug Fixes

*   auth failed without prompt ([8342ad2b](https://github.com/linuxdeepin/dde-polkit-agent/commit/8342ad2bf476ef933dc76079e41b72e639be2d17))



<a name="0.2.8"></a>
### 0.2.8 (2019-05-28)




<a name="0.2.7"></a>
### 0.2.7 (2019-05-27)


#### Features

*   show deepin-auth pam message ([f83eff25](https://github.com/linuxdeepin/dde-polkit-agent/commit/f83eff258e201ab080c71bddea98b2df93321288))



<a name="0.2.6"></a>
## 0.2.6 (2019-04-10)




<a name="0.2.5"></a>
## 0.2.5 (2019-04-09)




<a name="0.2.4"></a>
## 0.2.4 (2019-01-25)


#### Features

*   provide dbus service ([6383e78e](https://github.com/linuxdeepin/dde-polkit-agent/commit/6383e78e1a7da38cdfccb6c09223b2ed52bac521))



<a name="0.2.3"></a>
### 0.2.3 (2019-01-14)


#### Bug Fixes

*   still auth after dialog window closed ([76efc52f](https://github.com/linuxdeepin/dde-polkit-agent/commit/76efc52f4bce562aadbfb7adcc58acc922349d8e))



<a name="0.2.2"></a>
## 0.2.2 (2019-01-04)


#### Bug Fixes

*   failed on build ([8667450a](https://github.com/linuxdeepin/dde-polkit-agent/commit/8667450a19f1fabb5b836150f8754b529df7a5cd))



<a name="0.2.1"></a>
### 0.2.1 (2018-03-28)

*   Fix translate not load


<a name=""></a>
##  0.2.0 (2018-03-09)


#### Bug Fixes

*   trigger plugin action only wen auth succeeded ([ed5f3a54](https://github.com/linuxdeepin/dde-polkit-agent/commit/ed5f3a547f90e2ad1df9ea7466b4e430c6c7b2f3))
*   Using linux-pam to provide translation ([f82c13ea](https://github.com/linuxdeepin/dde-polkit-agent/commit/f82c13eaed35619468955f3ca3f09d1fa3a03ff2))
*   Adapt lintian ([64f643ff](https://github.com/linuxdeepin/dde-polkit-agent/commit/64f643ff38baedd1c99e0f80b77c1ef43a10543a))
* **singleton:**  fix single instance may not work ([3ca61575](https://github.com/linuxdeepin/dde-polkit-agent/commit/3ca61575d2adca300fa35b49602b604fe3f2ab30))

#### Features

*   create pid file to cache folder ([e7204e64](https://github.com/linuxdeepin/dde-polkit-agent/commit/e7204e64daa38d5586c65582c850a47e154e9070))
*   support agent plugins ([de068f2a](https://github.com/linuxdeepin/dde-polkit-agent/commit/de068f2ae7b4f261a1d45f5b2219bcbbda7178be))
*   support single instance ([48e65507](https://github.com/linuxdeepin/dde-polkit-agent/commit/48e6550734dd9323b4b3416e03b04b4106e074fd))
* **dialog:**  show validation information ([fa5c1e8f](https://github.com/linuxdeepin/dde-polkit-agent/commit/fa5c1e8ffe6c5be4a760e27a873f2ee4f00788b9))
* **plugin:**  support option widgets ([ceffd7ba](https://github.com/linuxdeepin/dde-polkit-agent/commit/ceffd7ba686237607830b5895827e368255f5460))



